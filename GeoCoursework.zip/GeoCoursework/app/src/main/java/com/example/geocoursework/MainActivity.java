
/*  Starter project for Mobile Platform Development in Semester B Session 2018/2019
    You should use this project as the starting point for your assignment.
    This project simply reads the data from the required URL and displays the
    raw data in a TextField
*/

//
// Name                 _________________
// Student ID           _________________
// Programme of Study   _________________
//

// Update the package name to include your Student Identifier
package com.example.geocoursework;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.design.widget.NavigationView;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.GravityCompat;
//import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Timer;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP;
//Lewis McCafferty - S1504594
public class MainActivity extends AppCompatActivity
{
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";
    private ArrayList<SeismicEvent> eventsArray = new ArrayList<SeismicEvent>();;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private SeismicEvent lowestLatObj;
    private SeismicEvent highestLatObj;
    private SeismicEvent lowestMagObj;
    private SeismicEvent highestMagObj;
    private SeismicEvent furthestWestObj;
    private SeismicEvent furthestEastObj;
    private SeismicEvent shallowestObj;
    private SeismicEvent deepestObj;
    private TextView lowestLat;
    private TextView highestLat;
    private TextView highestMagnitude;
    private TextView lowestMagnitude;
    private TextView furthestEast;
    private TextView furthestWest;
    private TextView shallowest;
    private TextView deepest;
    private Handler refreshHandler;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public void onResume(){
        super.onResume();
        System.out.println("Resume");

    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        System.out.println("Create");
        setContentView(R.layout.activity_main);
        lowestLat = findViewById(R.id.lowestLat);
        highestLat = findViewById(R.id.highestLat);
        lowestMagnitude = findViewById(R.id.lowestMag);
        highestMagnitude = findViewById(R.id.highestMag);
        furthestEast = findViewById(R.id.furthestEast);
        furthestWest = findViewById(R.id.furthestWest);
        deepest = findViewById(R.id.deepest);
        shallowest = findViewById(R.id.shallowest);


        //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);

        if (internetConnected()) {
            new SurveyDownloadAsyncTask(urlSource).execute();

        }
        else{
            Toast.makeText(MainActivity.this,"No Internet Connection", Toast.LENGTH_SHORT).show();
            if(!eventsArray.isEmpty())
            {
                System.out.println(eventsArray);
                setTextViews();
            }
            else
            {
                System.out.println(eventsArray);
                hideViewsNoConnection();
                ProgressBar progressBar = findViewById(R.id.progress);
                progressBar.setVisibility(View.GONE);
            }
        }

        //Navigation Bar Code
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        navigationView.setNavigationItemSelectedListener( new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                drawerLayout.closeDrawers();
                switch (menuItem.getItemId()) {
                    case R.id.nav_1: {
                        sendMessageSearchLocation();
                    }
                    break;
                    case R.id.nav_2: {
                        sendMessageSearchDate();
                        //menuItem.setChecked(false);
                    }
                    break;
                    case R.id.nav_map: {
                        sendMessageMap();
                    }
                    break;
                    case R.id.nav_refresh: {
                        finish();
                        startActivity(getIntent());
                    }
                    break;
                }
                return true;
            }});

        swipeRefreshLayout = findViewById(R.id.refresh);
        swipeRefreshLayout.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        finish();
                        startActivity(getIntent());
                    }
                }
        );

        //Toolbar Action Code
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ActionBar actionbar = getSupportActionBar();
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setHomeAsUpIndicator(R.drawable.ic_menu);
        actionbar.setTitle("Quake Coursework - S1504594");
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);

        this.refreshHandler= new Handler();
        this.refreshHandler.postDelayed(refreshRunnable, 900000);

    }

    //Refresh Code
    private final Runnable refreshRunnable = new Runnable()
    {
        public void run()

        {
            if (internetConnected()) {
                new SurveyDownloadAsyncTask(urlSource).execute();
                System.out.println("Downloading...");
                MainActivity.this.refreshHandler.postDelayed(refreshRunnable, 900000);
            }
        }

    };
    //END

    public void sendMessageSearchLocation() {
        Bundle bundle=new Bundle();
        bundle.putSerializable("objectArray", (Serializable) eventsArray );
        Intent intent = new Intent(this, LocationSearch.class);
        intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtras(bundle);
        startActivity(intent);
    }


    public void sendMessageSearchDate() {
        Bundle bundle=new Bundle();
        bundle.putSerializable("objectArray", (Serializable) eventsArray);
        Intent intent = new Intent(this, DateSearch.class);
        intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtras(bundle);
        startActivity(intent);
    }


    public void sendMessageMap(){
            Bundle bundle = new Bundle();
            bundle.putSerializable("objectArray", (Serializable) eventsArray);
            Intent intent = new Intent(this, MapsActivity.class);
            intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtras(bundle);
            startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
                System.out.println("OPENED..");
                return true;

        }
        return super.onOptionsItemSelected(item);
    }


    public void parseStream(InputStream inputStream) throws XmlPullParserException, IOException {


        //eventsArray = new ArrayList<SeismicEvent>();
        this.eventsArray = new ArrayList<SeismicEvent>(); //For Refresh
        String title = ""; String description=""; String link = "";
        String pubDate = ""; String category =""; double lat=0;
        double lon=0;


        System.out.println("RESULT:" + inputStream);
        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        factory.setNamespaceAware(true);
        XmlPullParser xpp = factory.newPullParser();

        xpp.setInput(inputStream, "UTF_8");
        int eventType = xpp.getEventType();
        SeismicEvent event;
        String currentTag = "";
        while (eventType != XmlPullParser.END_DOCUMENT)
        {
           if(eventType == XmlPullParser.START_TAG)
            {
                if (xpp.getName().equals("item"))
                {
                    boolean x = true;
                    while(x)
                    {
                        if(eventType == XmlPullParser.START_TAG)
                        {
                                currentTag = xpp.getName();
                        }
                        else if(eventType == XmlPullParser.TEXT)
                        {
                            if (currentTag.equals("title"))
                            {
                                title = xpp.getText();
                            }
                            else if (currentTag.equals("description"))
                            {
                                description = xpp.getText();
                               // System.out.println(description);
                            }
                            else if (currentTag.equals("link"))
                            {
                                link = xpp.getText();
                               // System.out.println(link);
                            }
                            else if (currentTag.equals("pubDate"))
                            {
                                pubDate = xpp.getText();
                               // System.out.println(pubDate);
                            }
                            else if (currentTag.equals("category"))
                            {
                                category = xpp.getText();
                                //System.out.println(category);
                            }
                            else if (currentTag.equals("lat"))
                            {
                                lat = Double.parseDouble(xpp.getText());
                            }
                            else if (currentTag.equals("long"))
                            {
                                lon = Double.parseDouble(xpp.getText());
                               // System.out.println(lon);
                            }
                            currentTag = "";
                        }
                        if (eventType == XmlPullParser.END_TAG)
                        {
                            if (xpp.getName().equals("item"))
                            {
                                x = false;
                                event = new SeismicEvent(title, description, link, pubDate, category, lat, lon);
                                eventsArray.add(event);
                            }


                        }
                        eventType = xpp.next();
                    }
                }
            }
            eventType = xpp.next();
        }
    }


    public void timerRefresh(){
        finish();
        startActivity(getIntent());
    }

    private class SurveyDownloadAsyncTask extends AsyncTask<Void, Integer, Void>
    {

        private String url;

        public SurveyDownloadAsyncTask(String aurl)
        {
            url = aurl;
        }

        ProgressBar progressBar = findViewById(R.id.progress);

        @Override
        protected Void doInBackground(Void... params)
        {
            URL aurl;
            URLConnection conn;
            BufferedReader in = null;
            try
            {
                aurl = new URL(url);
                conn = aurl.openConnection();
                InputStream inputStream = conn.getInputStream();
                parseStream(inputStream);
            }
            catch (Exception ae)
            {
                Log.e("MyTag", "ioexception");
            }

            MainActivity.this.runOnUiThread(new Runnable()
            {
                public void run() {
                    setTextViews();
                }
            });
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values)
        {
          super.onProgressUpdate(values);
          progressBar.setProgress(values[0]);

        }

        @Override
        protected void onPostExecute(Void result)
        {
            super.onPostExecute(result);
            progressBar.setVisibility(View.GONE);
            Toast.makeText(MainActivity.this,
                    "Download Complete", Toast.LENGTH_LONG).show();


        }
    }


    @SuppressLint("SetTextI18n")
    public void setTextViews()
    {
        largeAndLowMagnitude();
        calculateCompass();
        furthestEastAndWest();
        deepestAndShallowest();
        highestLat.setText("Furthest North" + "\n\n"+ highestLatObj.getLat() + "\n" + highestLatObj.getLocation()
                + "\n" + highestLatObj.getPubDate());
        lowestLat.setText("Furthest South" + "\n\n"+ lowestLatObj.getLat() + "\n" + lowestLatObj.getLocation()
                + "\n" + lowestLatObj.getPubDate());
        highestMagnitude.setText("Highest Magnitude" + "\n\n" + highestMagObj.getMagnitude() + "\n" + highestMagObj.getLocation() +
                "\n" + highestMagObj.getPubDate());
        lowestMagnitude.setText("Lowest Magnitude" + "\n\n" + lowestMagObj.getMagnitude() + "\n" + lowestMagObj.getLocation() +
                "\n" + lowestMagObj.getPubDate());
        furthestWest.setText("Furthest West" +"\n\n"+ furthestWestObj.getLocation() +"\n" + furthestWestObj.getLon()
                + "\n" + furthestWestObj.getPubDate());
        furthestEast.setText("Furthest East" +"\n\n" + furthestEastObj.getLocation() + "\n" + furthestEastObj.getLon()
                + "\n" + furthestEastObj.getPubDate());
        shallowest.setText("Shallowest" +"\n\n" + shallowestObj.getLocation() + "\n" + shallowestObj.getDepth()
                + "\n" + shallowestObj.getPubDate());
        deepest.setText("Deepest" +"\n\n" + deepestObj.getLocation() + "\n" + deepestObj.getDepth()
                + "\n" + deepestObj.getPubDate());

    }
    public void calculateCompass()
    {
        double lowestLat = eventsArray.get(0).getLat();
        double highestLat = eventsArray.get(0).getLat();
        highestLatObj =  eventsArray.get(0);
        lowestLatObj = eventsArray.get(0);


        for (SeismicEvent i: eventsArray)
        {

            if (i.getLat() > highestLat)
            {
                highestLat = i.getLat();
                highestLatObj = i;
            }
            else if (lowestLat > i.getLat())
            {

                lowestLat = i.getLat();
                lowestLatObj = i;
            }

        }
    }
    public void largeAndLowMagnitude(){

        double lowestNum = 0;
        double highestNum = 0;
        this.lowestMagObj = eventsArray.get(0);
        this.highestMagObj =  eventsArray.get(0);
        for (SeismicEvent i: eventsArray)
        {

            double parse = i.getParsedMagnitude();
            if (parse > highestNum)
            {
                highestNum = parse;
                highestMagObj = i;

            }
            else if (lowestNum > parse)
            {
                lowestNum = parse;
                lowestMagObj = i;
            }

        }
    }

    public void furthestEastAndWest(){
        double eastLon = eventsArray.get(0).getLon();
        double westLon = eventsArray.get(0).getLon();
        this.furthestEastObj =  eventsArray.get(0);
        this.furthestWestObj =  eventsArray.get(0);

        for (SeismicEvent i: eventsArray)
        {
            if (i.getLon() > eastLon)
            {
                eastLon = i.getLon();
                this.furthestEastObj = i;
            }
            else if (i.getLon() < westLon)
            {

                westLon = i.getLon();
                this.furthestWestObj= i;
            }

        }
    }

    @SuppressLint("SetTextI18n")
    public void hideViewsNoConnection(){
        highestLat.setText("No Internet Connection - Please Reload");
        lowestLat.setVisibility(View.GONE);
        highestMagnitude.setVisibility(View.GONE);
        lowestMagnitude.setVisibility(View.GONE);
        furthestWest.setVisibility(View.GONE);
        furthestEast.setVisibility(View.GONE);
        shallowest.setVisibility(View.GONE);
        deepest.setVisibility(View.GONE);
    }

    public boolean internetConnected()
    {
        Context context = this;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }
    public void deepestAndShallowest(){
        double shallow = eventsArray.get(0).getParsedDepth();
        this.shallowestObj = eventsArray.get(0);
        double deepest = eventsArray.get(0).getParsedDepth();
        this.deepestObj = eventsArray.get(0);

        for (SeismicEvent i: eventsArray)
        {
            if (i.getParsedDepth() > deepest)
            {
                deepest = i.getParsedDepth();
                this.deepestObj = i;
            }
            else if (i.getParsedDepth() < shallow)
            {
                shallow = i.getParsedDepth();
                this.shallowestObj= i;
                System.out.println(i.getParsedDepth());
            }

        }

    }

}
