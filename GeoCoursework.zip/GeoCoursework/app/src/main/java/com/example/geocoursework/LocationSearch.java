package com.example.geocoursework;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.View;

import java.io.Serializable;
import java.util.ArrayList;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP;
//Lewis McCafferty - S1504594
public class LocationSearch extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<SeismicEvent> eventsArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_search);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ActionBar actionbar = getSupportActionBar();
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setTitle("Quake Coursework - S1504594");

        recyclerView = (RecyclerView) findViewById(R.id.search_location_recycle_view);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        Bundle bundle =this.getIntent().getExtras();
        eventsArray = (ArrayList<SeismicEvent>) bundle.getSerializable("objectArray");

        SearchView sv = findViewById(R.id.search);
        initialLoad();

        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                callSearch(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                callSearch(s);
                return false;
            }
        });
        sv.setIconifiedByDefault(false);
        sv.setQueryHint("Search Example: HIGHLAND");

    }

    public void callSearch(String query) {
        ArrayList items = new ArrayList();

        for (SeismicEvent i: eventsArray)
        {
            if(i.getTitle().contains(query.toUpperCase()))
            {
                items.add(i);
            }
        }

        mAdapter = new LocationSearchAdapter(items);
        recyclerView.setAdapter(mAdapter);


    }


    public void initialLoad(){
        ArrayList items = new ArrayList();
        for (SeismicEvent i : eventsArray) {
            items.add(i);
        }

        mAdapter = new LocationSearchAdapter(items);
        ((LocationSearchAdapter) mAdapter).setOnItemClickListener(
                new LocationSearchAdapter.ClickListener() {
            @Override
            public void onItemClick(int position, View v) {
               LocationMapFragment locationMapFragment = new LocationMapFragment();
               SeismicEvent clickedEvent = ((LocationSearchAdapter) mAdapter).getItemEvent(position);
               Bundle bundle=new Bundle();
               bundle.putSerializable("objectEvent", (Serializable) clickedEvent);
               Intent intent = new Intent(v.getContext(), LocationMapFragment.class);
               intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP);
               intent.putExtras(bundle);
               startActivity(intent);

            }

            @Override
            public void onItemLongClick(int position, View v) {
                System.out.println("HOLDING");
            }
        });

        recyclerView.setAdapter(mAdapter);


    }
}
