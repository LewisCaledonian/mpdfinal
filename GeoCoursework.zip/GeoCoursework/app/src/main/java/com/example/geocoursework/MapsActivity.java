package com.example.geocoursework;

import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.support.v7.app.AppCompatActivity;
import android.view.OrientationEventListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
//Lewis McCafferty - S1504594
public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, AdapterView.OnItemSelectedListener {

    private GoogleMap mMap;
    private ArrayList<SeismicEvent> eventsArray;
    private BitmapDescriptor blueQuake;
    private BitmapDescriptor yellowQuake;
    private BitmapDescriptor greenQuake;
    private Spinner spinner;


    public void initialise()
    {

    }

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_maps);
            Button backButton = findViewById(R.id.backButton);
            backButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    finish();
                }
            });
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);
            Bundle bundle = this.getIntent().getExtras();
            eventsArray = (ArrayList<SeismicEvent>) bundle.getSerializable("objectArray");

            this.yellowQuake = BitmapDescriptorFactory.defaultMarker(
                    BitmapDescriptorFactory.HUE_YELLOW);
            this.blueQuake = BitmapDescriptorFactory.defaultMarker(
                    BitmapDescriptorFactory.HUE_BLUE);
            this.greenQuake = BitmapDescriptorFactory.defaultMarker(
                    BitmapDescriptorFactory.HUE_GREEN);
            spinner = findViewById(R.id.view_spinner);
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.map_spinner, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner.setOnItemSelectedListener(this);


        } catch (Exception ex)
        {
            finish();
            Toast.makeText(MapsActivity.this,"Cant Open Maps - Update Google Play", Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public void onResume(){
        super.onResume();
        if(mMap != null){
            mMap.clear();
        }
        spinner.setSelection(0);


    }


    public void addMarkers(){
        if (mMap != null){
            mMap.clear();
        }
        if(!eventsArray.isEmpty())
        {
            try {
                LatLng mostRecent = new LatLng(eventsArray.get(0).getLat(), eventsArray.get(0).getLon());
                for (SeismicEvent i : eventsArray) {
                    LatLng event = new LatLng(i.getLat(), i.getLon());
                    if (i.getParsedMagnitude() >= 2) {
                        mMap.addMarker(new MarkerOptions().position(event).icon(yellowQuake).title(i.getLocation()));
                    } else if (i.getParsedMagnitude() >= 1) {
                        mMap.addMarker(new MarkerOptions().position(event).icon(greenQuake).title(i.getLocation()));
                    } else {
                        mMap.addMarker(new MarkerOptions().position(event).icon(blueQuake).title(i.getLocation()));
                    }

                }
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mostRecent, 6));
            }
            catch (Exception ex)
            {
                System.err.print("RESET!");
            }
        }
        else if (eventsArray.isEmpty())
        {
            Toast.makeText(MapsActivity.this,"No Events to Load", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.mMap = googleMap;
        addMarkers();
    }

    public void onItemSelected(AdapterView<?> parent, View view,
                               int pos, long id) {

        switch ((String) parent.getSelectedItem()) {
            case "All":
                addMarkers();
                System.out.println("ALL");
                break;
            case "High Magnitude":
                addHighMarkers();
                System.out.println("High");
                break;
            case "Medium Magnitude":
                addMediumMarkers();
                System.out.println("Medium");
                break;
            case "Low Magnitude":
                addLowMarkers();
                System.out.println("Low");
                break;
        }

    }

    public void addLowMarkers(){
        if (mMap != null){
            mMap.clear();
        }

        if(!eventsArray.isEmpty())
        {
            LatLng mostRecent = new LatLng(eventsArray.get(0).getLat(), eventsArray.get(0).getLon());
            for (SeismicEvent i : eventsArray) {
                if (i.getParsedMagnitude() < 1) {
                    LatLng event = new LatLng(i.getLat(), i.getLon());
                    mMap.addMarker(new MarkerOptions().position(event).icon(blueQuake).title(i.getLocation()));
                }
            }
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mostRecent, 6));
        }
        else if (eventsArray.isEmpty())
        {
            Toast.makeText(MapsActivity.this,"No Events to Load", Toast.LENGTH_SHORT).show();
        }
    }

    public void addMediumMarkers(){
        if (mMap != null){
            mMap.clear();
        }
        if(!eventsArray.isEmpty())
        {
            LatLng mostRecent = new LatLng(eventsArray.get(0).getLat(), eventsArray.get(0).getLon());
            for (SeismicEvent i : eventsArray) {
                if (i.getParsedMagnitude() >= 1 && i.getParsedMagnitude() < 2) {
                    LatLng event = new LatLng(i.getLat(), i.getLon());
                    mMap.addMarker(new MarkerOptions().position(event).icon(greenQuake).title(i.getLocation()));
                }
            }
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mostRecent, 6));
        }
        else if (eventsArray.isEmpty())
        {
            Toast.makeText(MapsActivity.this,"No Events to Load", Toast.LENGTH_SHORT).show();
        }
    }

    public void addHighMarkers(){
        if (mMap != null){
            mMap.clear();
        }
        if(!eventsArray.isEmpty())
        {
            LatLng mostRecent = new LatLng(eventsArray.get(0).getLat(), eventsArray.get(0).getLon());
            for (SeismicEvent i : eventsArray) {
                if (i.getParsedMagnitude() >= 2) {
                    LatLng event = new LatLng(i.getLat(), i.getLon());
                    mMap.addMarker(new MarkerOptions().position(event).icon(yellowQuake).title(i.getLocation()));
                }
            }
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mostRecent, 6));
        }
        else if (eventsArray.isEmpty())
        {
            Toast.makeText(MapsActivity.this,"No Events to Load", Toast.LENGTH_SHORT).show();
        }
    }

    public void onNothingSelected(AdapterView<?> parent) {
    }

}
