package com.example.geocoursework;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

//Lewis McCafferty - S1504594

public class DateSearch extends AppCompatActivity {

    private ArrayList<SeismicEvent> eventsArray;
    private LinearLayout itemsLayout;
    private RecyclerView recyclerView;
    private ScrollView hiddenScroll;
    private RecyclerView.Adapter pureAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private TextView textView;
    private TextView textView2;
    private TextView textView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_search);
        Toolbar toolbar = findViewById(R.id.toolbar);
        hiddenScroll = findViewById(R.id.hiddenScroll);
        setSupportActionBar(toolbar);
        final ActionBar actionbar = getSupportActionBar();
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setTitle("Quake Coursework - S1504594");
        Bundle bundle = this.getIntent().getExtras();
        eventsArray = (ArrayList<SeismicEvent>) bundle.getSerializable("objectArray");


        recyclerView = (RecyclerView) findViewById(R.id.search_date_recycle_view);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        itemsLayout = findViewById(R.id.itemsLayout);
        itemsLayout.setVisibility(View.GONE);
    }

    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }


    HashMap<Integer, String> hashMonth = new HashMap<Integer, String>() {{
        put(1, "Feb");
        put(5, "Jun");
        put(2, "Mar");
        put(6, "Jul");
        put(3, "Apr");
        put(7, "Aug");
        put(4, "May");
        put(8, "Sep");
        put(9, "Oct");
        put(10, "Nov");
        put(11, "Dec");
        put(0, "Jan");
    }};

    public void dateSearch(int day, int month, int year) {
        ArrayList items = new ArrayList();
        String query = day + " " + hashMonth.get(month) + " " + year;

        for (SeismicEvent i : eventsArray) {

            if (i.getPubDate().toUpperCase().contains(query.toUpperCase())) {
                items.add(i);
            }
        }

        if (items.isEmpty()) {
            DialogFragment newFragment = new DateDialogFragment();
            newFragment.show(getSupportFragmentManager(), "dateDialog");
        }

        if (items.size() > 0) {
            calculateDataItems(items);
            itemsLayout.setVisibility(View.VISIBLE);
            hiddenScroll.setVisibility(View.VISIBLE);
        }
        else
        {
          itemsLayout.setVisibility(View.GONE);
          hiddenScroll.setVisibility(View.GONE);
        }

        pureAdapter = new DateSearchAdapter(items);
        recyclerView.setAdapter(pureAdapter);

    }

    @SuppressLint("SetTextI18n")
    public void calculateDataItems(ArrayList<SeismicEvent> eventsArray) {

        double lowestLat = eventsArray.get(0).getLat();
        double highestLat = eventsArray.get(0).getLat();
        double lowestNum = eventsArray.get(0).getParsedMagnitude();
        double highestNum = eventsArray.get(0).getParsedMagnitude();
        double eastLon = eventsArray.get(0).getLon();
        double westLon = eventsArray.get(0).getLon();
        double shallow = eventsArray.get(0).getParsedDepth();
        double deepest = eventsArray.get(0).getParsedDepth();

        textView =  findViewById(R.id.holderText);
        textView2 = findViewById(R.id.holderText2);
        textView3 = findViewById(R.id.holderText3);


        for (SeismicEvent i : eventsArray) {

            if (i.getLat() > highestLat) {
                highestLat = i.getLat();
                // objectEvents.add(0, i);
            } else if (lowestLat > i.getLat()) {

                // objectEvents.add(1, i);
                lowestLat = i.getLat();

            }
            if (i.getLon() > eastLon) {
                // objectEvents.add(2, i);
                eastLon = i.getLon();
            } else if (i.getLon() < westLon) {

                // objectEvents.add(3, i);
                westLon = i.getLon();
            }
            double parse = i.getParsedMagnitude();
            if (parse > highestNum) {
                // objectEvents.add(4, i);
                highestNum = parse;

            } else if (lowestNum > parse) {
                // objectEvents.add(5, i);
                lowestNum = parse;

            }
            if (i.getParsedDepth() > deepest) {
                // objectEvents.add(6, i);
                deepest = i.getParsedDepth();
            } else if (i.getParsedDepth() < shallow) {
                //objectEvents.add(7, i);
                shallow = i.getParsedDepth();
            }

            textView.setText("Map Positions:\n"
                    + "North:  " + highestLat + " " +
                    "South: " + lowestLat + "\n" +
                    "West: " + westLon  + " " +
                    "East: " + eastLon);

            textView2.setText("Quake Depth:\n"
                    + "Deepest: " + deepest + " " +
                    "Shallowest: " + shallow);

            textView3.setText("Quake Magnitude:\n"
                    + "Strongest Detected: " + highestNum + "\n" +
                    "Weakest Detected: " + lowestNum);
        }

    }
}
