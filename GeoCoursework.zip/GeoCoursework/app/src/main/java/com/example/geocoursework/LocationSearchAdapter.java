package com.example.geocoursework;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
//Lewis McCafferty - S1504594
public class LocationSearchAdapter extends RecyclerView.Adapter<LocationSearchAdapter.MyViewHolder> {
    private TextView textView;
    private TextView textView2;
    private TextView textView3;
    private TextView textView4;
    private TextView textView5;
    private ArrayList<SeismicEvent> seismicEventsList;
    private static ClickListener clickListener;


    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {
        public LinearLayout linearView;
        public MyViewHolder(LinearLayout v) {
            super(v);
            v.setOnClickListener(this);
            v.setOnLongClickListener(this);
            linearView = v;
        }

        @Override
        public void onClick(View v) {
            clickListener.onItemClick(getAdapterPosition(), v);
        }

        @Override
        public boolean onLongClick(View v) {
            clickListener.onItemLongClick(getAdapterPosition(), v);
            return false;
        }
    }

    public interface ClickListener {
        void onItemClick(int position, View v);
        void onItemLongClick(int position, View v);
    }


    public LocationSearchAdapter(ArrayList<SeismicEvent> seismicEvents)
    {
        seismicEventsList = seismicEvents;
    }

    @Override
    public LocationSearchAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // create a new view

        LinearLayout v = (LinearLayout)  LayoutInflater.from(parent.getContext())
                .inflate(R.layout.text_view_main, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position){
        textView = holder.linearView.findViewById(R.id.holderText);
        textView2 = holder.linearView.findViewById(R.id.holderText2);
        textView3 = holder.linearView.findViewById(R.id.holderText3);
        textView4 = holder.linearView.findViewById(R.id.holderText4);
        textView5 = holder.linearView.findViewById(R.id.holderText5);

        double parse = Double.parseDouble(seismicEventsList.get(position).getMagnitude().split(":")[1]);
        if (parse >= 2)
        {
            textView2.setTextColor(Color.YELLOW);
            textView2.setText(seismicEventsList.get(position).getMagnitude());
        }
        if (parse < 2 && parse >= 1)
        {
            textView2.setTextColor(Color.GREEN);
            textView2.setText(seismicEventsList.get(position).getMagnitude());
        }
        if (parse < 1)
        {
            textView2.setTextColor(Color.WHITE);
            textView2.setText(seismicEventsList.get(position).getMagnitude());
        }

        textView.setText(seismicEventsList.get(position).getLocation());
        //textView2.setText(seismicEventsList.get(position).getMagnitude());
        textView3.setText(seismicEventsList.get(position).getPubDate());
        textView4.setText(seismicEventsList.get(position).getDepth());
        String latLon = "Lat: "+ Double.toString(seismicEventsList.get(position).getLat()) + "  Lon: "
                + Double.toString(seismicEventsList.get(position).getLon());
        textView5.setText(latLon);



    }

    public SeismicEvent getItemEvent(int position){
        return seismicEventsList.get(position);
    }

    @Override
    public int getItemCount() {
        return seismicEventsList.size();
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        LocationSearchAdapter.clickListener = clickListener;
    }

}
