package com.example.geocoursework;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class DateSearchAdapter extends RecyclerView.Adapter<DateSearchAdapter.MyViewHolder>{
//Lewis McCafferty - S1504594

    private TextView textView;
    private TextView textView2;
    private TextView textView3;
    private ArrayList<SeismicEvent> seismicEventsList;


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public LinearLayout linearView;
        public MyViewHolder(LinearLayout v) {
            super(v);
            linearView = v;
        }
    }


    public DateSearchAdapter(ArrayList<SeismicEvent> seismicEvents)
    {
        seismicEventsList = seismicEvents;
    }

    @Override
    public DateSearchAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // create a new view

        LinearLayout v = (LinearLayout)  LayoutInflater.from(parent.getContext())
                .inflate(R.layout.date_search_view, parent, false);
        DateSearchAdapter.MyViewHolder vh = new DateSearchAdapter.MyViewHolder(v);
        return vh;
    }



    @Override
    public void onBindViewHolder(final DateSearchAdapter.MyViewHolder holder, final int position){

        textView = holder.linearView.findViewById(R.id.holderText);
        textView2 = holder.linearView.findViewById(R.id.holderText2);
        textView3 = holder.linearView.findViewById(R.id.holderText3);

        double parse = Double.parseDouble(seismicEventsList.get(position).getMagnitude().split(":")[1]);
        if (parse >= 2)
        {
            textView2.setTextColor(Color.YELLOW);
            textView2.setText(seismicEventsList.get(position).getMagnitude());
        }
        if (parse >= 1 && parse < 2)
        {
            textView2.setTextColor(Color.GREEN);
            textView2.setText(seismicEventsList.get(position).getMagnitude());
        }
        if (parse < 1)
        {
            textView2.setTextColor(Color.WHITE);
            textView2.setText(seismicEventsList.get(position).getMagnitude());
        }


        textView.setText(seismicEventsList.get(position).getLocation());
        textView3.setText(seismicEventsList.get(position).getPubDate());

    }

    @Override
    public int getItemCount() {
        return seismicEventsList.size();
    }

}
