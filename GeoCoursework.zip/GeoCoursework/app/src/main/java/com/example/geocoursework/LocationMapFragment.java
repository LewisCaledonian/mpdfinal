package com.example.geocoursework;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

//Lewis McCafferty - S1504594
public class LocationMapFragment extends FragmentActivity implements OnMapReadyCallback{
    private GoogleMap mMap;
    private SeismicEvent event;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location_search_map);
        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Bundle bundle =this.getIntent().getExtras();
        event = (SeismicEvent) bundle.getSerializable("objectEvent");



    }

    public void addMarkers(){
            mMap.clear();
            LatLng eventLatLon = new LatLng(this.event.getLat(), this.event.getLon());
            mMap.addMarker(new MarkerOptions().position(eventLatLon).title(this.event.getLocation()));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(eventLatLon, 6));
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.mMap = googleMap;
        addMarkers();
    }



    public void onNothingSelected(AdapterView<?> parent) {
    }
}
