package com.example.geocoursework;

import java.io.Serializable;
//Lewis McCafferty - S1504594
public class SeismicEvent implements Serializable {

    private String title;
    private String description;
    private String link;
    private String pubDate;
    private String category;
    private double lat;
    private double lon;
    private String alert;
    private String scale;
    private String location;
    private String depth;
    private String magnitude;


    public SeismicEvent()
    {

    }


    public SeismicEvent(String title, String description, String link, String pubDate, String category, double lat, double lon) {
        this.title = title;
        this.description = description;
        this.link = link;
        this.pubDate = pubDate;
        this.category = category;
        this.lat = lat;
        this.lon = lon;
        parseTitle(title);
        parseDescription(description);
    }

    public void parseTitle(String title){
        String del = ":";
        String[] splitTitle = title.split(del);
        this.alert = splitTitle[0];
        this.scale = splitTitle[1].replaceFirst(" ","");;
    }

    public void parseDescription(String description){
        String del = ";";
        String[] splitDescription = description.split(del);
        String locationParse = splitDescription[1].replaceFirst(" ","");
        this.location = locationParse.split(":")[1].replaceFirst(" ", "");
        this.depth = splitDescription[3].replaceFirst(" ","");;
        this.magnitude = splitDescription[4].replaceFirst(" ","");;

    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getLink() {
        return link;
    }

    public String getPubDate() {
        return pubDate;
    }

    public String getCategory() {
        return category;
    }

    public String getAlert() { return  alert;}

    public String getScale() {return  scale;}

    public String getLocation() {return location;}

    public String getDepth() {return depth;}

    public String getMagnitude(){return magnitude;}

    public double getLat() {
        return lat;
    }

    public double getLon() {
        return lon;
    }

    public double getParsedDepth(){

        String splitDepth[] = this.getDepth().split("[:]");
        String num[] = splitDepth[1].replaceFirst(" ", "").split(" ");
        return Double.parseDouble(num[0]);
    }

    public double getParsedMagnitude(){
       return Double.parseDouble(getMagnitude().split(":")[1]);
    }





}
